<?php
/*
 * Template Name: What we do
 */
?>
<?php get_header(); ?>
<main>
    <?php the_title(); ?>
    <?php get_template_part('includes/section', 'content'); ?>
</main>
<?php get_footer(); ?>
