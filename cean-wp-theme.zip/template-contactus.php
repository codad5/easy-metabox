<?php
/*
 * Template Name: Contact Us
 */
?>
<?php get_header(); ?>
<div class="w-full px-4 lg:px-20 py-14">
    <div class="w-full h-full flex flex-col lg:flex-row gap-x-7 items-center">
        <div class="w-full py-5 lg:py-0 lg:w-1/4 lg:px-7 border-r border-r-[#262626]">
            <?php get_template_part('template-parts/commons/contact-card', null, [
                'section_title' => __('General Inquiries', 'cean-wp-theme'),
                'contact_methods' => [
                    [
                        'title' => 'https://ceanigeria.com',
                        'url' => 'https://ceanigeria.com',
                    ],
                    [
                        'title' => '+234 802 663 1773 ',
                        'url' => 'tel:+2348026631773',
                    ]
                ]]); ?>
        </div>
        <div class="w-full lg:w-1/4 py-5 lg:py-0 lg:px-7 border-r border-r-[#262626]">
            <?php get_template_part('template-parts/commons/contact-card', null, [
                'section_title' => __('Technical Support', 'cean-wp-theme'),
                'contact_methods' => [
                    [
                        'title' => 'contact@ceanigeria.com',
                        'url' => 'mailto:contact@ceanigeria.com'
                    ],
                    [
                        'title' => '+234 802 663 1773 ',
                        'url' => 'tel:+2348026631773',
                    ]
                ]]); ?>
        </div>
        <div class="w-full lg:w-1/4 py-5 lg:py-0 lg:px-7 border-r border-r-[#262626]">
            <div class="w-full flex flex-col justify-center items-center gap-7">
                <div class="w-full ">
                    <h3 class="font-normal text-lg">
                        Our Office
                    </h3>
                </div>
                <div class="w-full flex flex-col gap-2.5 px-5 lg:px-0">
                    <div class="w-full text-base font-normal text-[#999999]">
                        15 Commercial Avenue, Sabo Yaba, Lagos
                    </div>
                    <div class="w-max py-3.5 px-5 border border-[#262626] bg-[#1A1A1A] rounded-md">
                        <a class="font-normal text-sm text-[#999999] flex gap-1" href="tel:+2348026631773">
                            Get Directions
                            <div class="inline-block w-5 aspect-square">
                                <img src="<?php echo CeanWP_Functions::get_common_icon_url('external-link'); ?>" alt="external-link" class="w-full h-full object-contain" />
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-full lg:w-1/4 py-5 lg:py-0">
            <div class="w-full flex flex-col justify-center items-center gap-5 lg:gap-7">
                <div class="w-full ">
                    <h3 class="font-normal text-base lg:text-lg">
                        Connect with Us
                    </h3>
                </div>
                <div class="w-full flex gap-2.5 h-12 justify-between lg:justify-start">
                    <?php
                    $socials = CeanWP_Functions::get_contact_socials();
                    ?>
                    <?php foreach ($socials as $social) : ?>
                        <div class="h-full w-1/3 lg:w-max grid place-items-center px-3.5 bg-[#1A1A1A] rounded-md">
                            <a href="<?php echo esc_url($social['url']); ?>">
                                <img class="h-full" src="<?php echo esc_url(CeanWP_Functions::get_common_icon_url($social['icon'])); ?>" alt="<?php echo esc_attr($social['title']); ?>" />
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="w-full px-4 lg:px-20 bg-[#1A1A1A] py-16">
    <div class="w-full flex flex-col gap-2.5">
        <div class="w-full">
            <h3 class="font-semibold text-4xl">
                Get in Touch
            </h3>
        </div>
        <div class="w-full font-normal text-base text-[#999999]">
            We value your feedback, questions, and concerns at Nutritionist. Our dedicated team is here to assist you and provide the support you need on your nutritional journey. Please don't hesitate to reach out to us using any of the following contact methods.
        </div>
    </div>
</div>
<?php get_template_part('template-parts/contactus/contact-us-form'); ?>
<?php get_template_part('template-parts/contactus/faqs'); ?>
<?php get_footer(); ?>
