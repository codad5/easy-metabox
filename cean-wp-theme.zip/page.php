<?php get_header(); ?>
    <main>
<!--        --><?php //the_title(); ?>
<!--        --><?php //get_template_part('includes/section', 'content'); ?>
<!--        This is a page temp-->
    </main>
<?php get_footer(); ?>